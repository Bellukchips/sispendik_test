class ApiService{
  static String login = "http://192.168.1.13/project-laravel/sispendik/api/signin.php";
  static String registerEmployee = "http://192.168.1.13/project-laravel/sispendik/api/register_employee.php";
  static String registerStudent = "http://192.168.1.13/project-laravel/sispendik/api/register_student.php";
  static String update_profile = "http://192.168.1.13/project-laravel/sispendik/api/update_profile.php";
  static String update_profil = "http://192.168.1.13/project-laravel/sispendik/api/update_profil.php";
  static String update_password = "http://192.168.1.13/project-laravel/sispendik/api/update_password.php";
  static String showImage = "http://192.168.1.13/project-laravel/sispendik/uploads/";
}